# Preprocessing_and_QC

The flowchart of preprocessing and quality control of fMRI images.

![alt text](https://github.com/Brain-Connectivity-Lab/Preprocessing_and_QC/blob/main/Pics/Flowchart.jpg)
